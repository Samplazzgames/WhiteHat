class Hexagon{
    cconstructor(x, y , radius) {
        super(x , y , 20)
        // var options = {
        //     bodyA: bodyA,
        //     pointB: pointB,
        //     stiffness: 0.04,
        //     length: 10         
        }
        // this.body = Bodies.circle(x, y, height, options);
        // this.width = width;
        // this.height = height;
        // World.add(world, this.body);
        display(){
            super.display();
      }
        // var angle = this.body.angle;
        // var pos= this.body.position;
        // push();
        // translate(pos.x, pos.y);
        // rotate(angle);

        // pop();
      }